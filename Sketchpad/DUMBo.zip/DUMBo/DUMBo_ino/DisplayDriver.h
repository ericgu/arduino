

class DisplayDriver
{
  public:
    static void setSegment(int value);
  
    static void showCurrentValue(int value, int dimLevel);
};

